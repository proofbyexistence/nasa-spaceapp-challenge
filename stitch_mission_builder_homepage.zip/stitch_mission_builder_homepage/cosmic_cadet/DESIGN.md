---
name: Cosmic Cadet
colors:
  surface: '#12093d'
  surface-dim: '#12093d'
  surface-bright: '#383265'
  surface-container-lowest: '#0c0338'
  surface-container-low: '#1a1345'
  surface-container: '#1e1849'
  surface-container-high: '#292354'
  surface-container-highest: '#342e60'
  on-surface: '#e5deff'
  on-surface-variant: '#e0bfbd'
  inverse-surface: '#e5deff'
  inverse-on-surface: '#2f295b'
  outline: '#a78a88'
  outline-variant: '#584140'
  surface-tint: '#ffb3b0'
  primary: '#ffb3b0'
  on-primary: '#68000f'
  primary-container: '#ff6b6b'
  on-primary-container: '#6d0010'
  inverse-primary: '#ae2f34'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#e8c426'
  on-tertiary: '#3b2f00'
  tertiary-container: '#caa800'
  on-tertiary-container: '#4c3e00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad8'
  primary-fixed-dim: '#ffb3b0'
  on-primary-fixed: '#410006'
  on-primary-fixed-variant: '#8c1520'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ffe173'
  tertiary-fixed-dim: '#e8c426'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#554500'
  background: '#12093d'
  on-background: '#e5deff'
  surface-variant: '#342e60'
typography:
  headline-xl:
    fontFamily: Rubik
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
  headline-xl-mobile:
    fontFamily: Rubik
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
  headline-lg:
    fontFamily: Rubik
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Rubik
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
  headline-md:
    fontFamily: Rubik
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  headline-sm:
    fontFamily: Rubik
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Nunito Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Nunito Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Nunito Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-lg:
    fontFamily: Rubik
    fontSize: 16px
    fontWeight: '700'
    lineHeight: 24px
  label-md:
    fontFamily: Rubik
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-sm:
    fontFamily: Rubik
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-sm: 0.75rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system channels an optimistic "cartoon space-camp" aesthetic blended with tactile mission-control telemetry. Designed for young explorers and aspiring aerospace engineers aged 10–20, it balances playful curiosity with authentic mission mechanics. 

The visual personality combines chunky, sticker-like components and deep-space atmospheric depth. Interfaces should feel like a physical, futuristic flight console crossed with an interactive aerospace journal: tactile, bouncy, and highly encouraging, avoiding clinical coldness while preserving structural clarity.

## Colors

The palette operates entirely in dark mode, built upon a rich cosmic base that makes vivid accents leap forward.

- **Background Canvas (`#1B1446`)**: Midnight cosmic navy, grounding all viewport layouts and game stages.
- **Primary / Action Coral (`#FF6B6B`)**: Ignitions, launches, primary calls to action, and alerts.
- **Secondary / Telemetry Sky Blue (`#38BDF8`)**: Data panels, orbital paths, navigational elements, and active states.
- **Tertiary / Solar Yellow (`#FFD93D`)**: Trophies, fuel gauges, warnings, and achievement stars.
- **Life-Support Mint (`#4ADE80`)**: System health checks, successful configurations, and positive validation.
- **Hyperdrive Violet (`#A78BFA`)**: Science modules, payload slots, and badge accents.
- **Structural Containers (`#241B5C` to `#2E2375`)**: Layered depths for panels, structural cards, and mission slots.

Functional feedback strictly adheres to chromatic cues: Mint for functional systems, Solar Yellow for threshold warnings, and Coral for critical balance or weight breaches.

## Typography

The typographic hierarchy pairs the soft, stout geometry of Rubik for display and structural labels with the high legibility of Nunito Sans for mission logs, specs, and narrative dialogue.

- **Display & Headers (Rubik)**: Set heavy (weights 700–800) with compact line heights to mimic chunky mission patches and dynamic flight HUDs.
- **Body & Specs (Nunito Sans)**: Clean, open counters ensure that engine statistics, payload metrics, and system tutorials are read effortlessly across diverse screen sizes.
- **Labels & Badges (Rubik)**: High-weight labels ensure visual impact on buttons, badges, and toggle switches.

## Layout & Spacing

The layout is built on a responsive 12-column fluid grid tailored for drag-and-drop mission building, blueprint canvases, and real-time telemetry sidebars.

- **Desktop (1024px+)**: 12 columns with `2rem` margins and `1.25rem` gutters. Canvas stages split between an 8-column assembly yard and a 4-column module/spec tray.
- **Tablet (768px - 1023px)**: 8 columns with `1.5rem` margins and `1rem` gutters. Sidebars fold into collapsible overlay drawers.
- **Mobile (< 768px)**: 4 columns with `1rem` margins and `0.75rem` gutters. Stacks the visual rocket staging vertically above the module picker carousel.
- **Component Rhythms**: Use `space-md` for standard card padding and `space-sm` for tight telemetry stats grids.

## Elevation & Depth

This system avoids realistic drop shadows in favor of vibrant, atmospheric depth and layered game-chassis realism:

- **Sticker Borders**: Containers, cards, and floating elements use solid 2px or 3px outlines (`#2E2375` or full white/accent keys) to emulate physical vinyl mission stickers and chassis panels.
- **Glow Highlights**: Interactive and status-bearing items utilize soft neon exterior blurs (0px 0px 16px) tinted directly to the active token (Coral for thrusters, Mint for operational status, Sky Blue for selected stages).
- **Physical Extrusion**: Buttons and active cards feature solid-color bottom offsets (e.g., 4px bottom border or solid shadow in `#120C31`) to provide a satisfying, mechanical, tactile press upon interaction.
- **Surface Layering**: 
  - Base canvas: `#1B1446`
  - Module bay / Shelf: `#241B5C`
  - Floating blueprints / Dialogue cards: `#2E2375` with 3px solid borders.

## Shapes

The design system employs a distinctly chunky, high-radius silhouette throughout all components. 

- **Primary Interactive Elements**: Fully pill-shaped (`rounded-full` or 9999px) for buttons, status chips, and control toggles.
- **Cards, Panels & Viewports**: Formed with exaggerated `20px` corners, lending a friendly, toy-like feel that softens technical data and complex diagrams.
- **Blueprint Slots**: Hollowed drop zones feature dashed outlines and identical corner curvatures to welcome dropped components.

## Components

### Buttons
- **Primary ("Launch")**: Pill-shaped, Coral (`#FF6B6B`) fill with 3px bottom offset border (`#D94B4B`). White text in Rubik bold. On hover: bouncy scale up (`1.04`), with bottom offset compressing on click (`:active translateY(2px)`).
- **Secondary ("Inspect")**: Pill-shaped Sky Blue outline (2px) on `#241B5C` background with subtle sky-blue back-glow.

### Cosmic Badges & Chips
- Chunky, pill-shaped tags featuring 2px solid sticker borders.
- Backgrounds use 20% opacity of their respective accent colors (e.g., 20% `#4ADE80` with solid `#4ADE80` border and text).
- Includes an icon slot for orbital icons, fuel indicators, or science beaker symbols.

### Blueprint Cards
- Deep violet surface (`#2E2375`) framed with a 2.5px solid border (`#3D2F96`).
- Integrated 20px border radius with a top-right corner notch or badge detailing stage mass, power consumption, and rocket compatibility.
- Interactive cards exhibit a distinct bounce lift and cyan glow when dragged.

### Inputs & Sliders
- **Numerical/Thrust Sliders**: Thick 12px pill tracks in `#1B1446` with bright gradient fill (Mint to Sky Blue). Thumb is an oversized 28px circular orb with an inner highlight and outer neon glow.
- **Text Inputs**: Recessed `#1B1446` fields with 2px borders that transition to Sunny Yellow or Sky Blue on focus.

### Checkboxes & Segmented Controls
- Segmented switches resemble mission-console rocker pads, housed inside a rounded dark capsule where selected states bounce into a vibrant pill indicator.
- Checkboxes are 24px rounded squares with solid 2px borders, animating a bold checkmark upon completion.

### Telemetry Gauges (Specialty Component)
- Radial or segmented vertical bar meters displaying payload limits, delta-v, and thermal friction. Segmented indicators light up from Sky Blue to Coral as thresholds near maximum capacity.